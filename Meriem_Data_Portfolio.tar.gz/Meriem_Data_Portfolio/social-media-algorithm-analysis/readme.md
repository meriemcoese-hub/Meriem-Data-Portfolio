
# How TikTok Works: What Drives Reach in 2025

This project explores a synthetic dataset representing TikTok video characteristics. We examine how factors like caption length, presence of a trending sound and number of hashtags correlate with view counts.

Key takeaways:
- Understanding how text length may influence user engagement.
- Generating and analysing synthetic data to simulate platform behaviour.
- Visualising feature relationships with scatter plots and correlation coefficients.

See `analysis.ipynb` for full details and `features_vs_views.png` for an example plot.
