
# Inside Airbnb: Pricing & Trends in Paris

This project demonstrates how to generate a synthetic Airbnb dataset for Paris, compute average prices by neighbourhood and visualise the results. The notebook explains the steps clearly and produces an illustrative bar chart.

Key takeaways:
- Understanding how price varies across arrondissements.
- Working with categorical and numerical data.
- Generating synthetic datasets for practice.

Find the notebook in `analysis.ipynb` and the chart in `avg_price_by_neighbourhood.png`.
