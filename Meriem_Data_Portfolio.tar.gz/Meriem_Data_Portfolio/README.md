
# Data Analysis Portfolio

This portfolio contains four data analysis projects created by Meriem. Each project illustrates a different aspect of analytical thinking, from exploratory visualisations to predictive modelling and market research. Although the datasets are synthetic, they mirror real‑world structures and problems.

## Projects

| Folder | Title | Description |
|-------|-------|-------------|
| `inside-airbnb-analysis` | Inside Airbnb: Pricing & Trends in Paris | An exploration of synthetic Airbnb listings across Paris arrondissements. Includes grouping, aggregation and a bar chart of average prices by neighbourhood. |
| `social-media-algorithm-analysis` | How TikTok Works: What Drives Reach in 2025 | A simulated TikTok engagement dataset. Investigates relationships between caption length, hashtags and views using correlation and scatter plots. |
| `customer-churn-analysis` | Why Customers Leave: A Data‑Driven Churn Analysis | A synthetic telecom dataset used to train a logistic regression model predicting customer churn. Demonstrates preprocessing, modelling and confusion matrix visualisation. |
| `job-market-analysis` | What Recruiters Want: A Data Analyst Job Market Study | A job postings dataset that counts and visualises the frequency of required skills, highlighting in‑demand technologies and soft skills. |

Each folder contains an `analysis.ipynb` notebook with code and explanations, relevant plots as PNG images and a `readme.md` summarising the project. You can run the notebooks in any Jupyter environment (e.g. Kaggle) to reproduce the results.
