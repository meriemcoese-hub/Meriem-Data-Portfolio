
# Why Customers Leave: A Data‑Driven Churn Analysis

This notebook constructs a synthetic telecom customer dataset and trains a logistic regression model to predict customer churn. It demonstrates data preprocessing (one‑hot encoding), model training, evaluation and visualisation of the confusion matrix.

Key takeaways:
- How to encode categorical variables and split data into training and test sets.
- Building a baseline logistic regression model.
- Interpreting the confusion matrix to understand model performance.

See the full notebook in `analysis.ipynb` and the confusion matrix image in `churn_confusion_matrix.png`.
