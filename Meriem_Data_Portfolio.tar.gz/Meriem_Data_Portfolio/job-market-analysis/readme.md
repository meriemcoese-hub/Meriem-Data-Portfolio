
# What Recruiters Want: A Data Analyst Job Market Study

In this synthetic job postings dataset we examine which skills appear most frequently. The notebook counts skill occurrences and visualises the results to reveal trends in employer demand.

Key takeaways:
- Python and SQL continue to be highly valued.
- Visualization skills such as Power BI and Tableau also feature prominently.
- Soft skills (communication, statistics) remain essential in many postings.

Explore the full analysis in `analysis.ipynb` and the skills frequency plot in `skills_frequency.png`.
